Gabrielle Merritt 
gmerritt@seas.upenn.edu 
CIS542 README 

How to run programs: 

In the make file there are only two programs, the default program which makes all the binaries for the assignment and make clean to delete all the binary files. 

You must call make from the lab1 folder or else the make and make clean will fail.

When calling make, it will generate a new folder called bin which contains all the binary files. 

Do not run the .bin.dSYM files, as I am not sure what they do or how to get rid of them! 

