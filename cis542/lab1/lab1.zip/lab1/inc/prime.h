#ifndef PRIME_H
#define PRIME_H
#include <stdio.h> 
#include <stdlib.h>
int is_prime(int n);

#endif // PRIME_H 