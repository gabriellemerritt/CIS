#ifndef LOGIC_RANDOM_H
#define LOGIC_RANDOM_H

#define MAX_GUESS 10 // set guesses 

int guessResolver(int luckynumber, int guess, int start);
int timeDif (int start, int end ); 

#endif // LOGIC_RANDOM_H