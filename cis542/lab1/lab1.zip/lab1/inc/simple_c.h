#ifndef SIMPLE_C_H
#define SIMPLE_C_H 

#define MAX_BUF 1024 // setting max buffer length to prevent overflow 

void parseName(char* argv[], int length);  
void reverseString(char* buffer_point); 
#endif // SIMPLE_C_H 
